
package application;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MorseCodeTreeTest {
    
    MorseCodeTree tree;
    ArrayList<String> testArr;
    
    @BeforeEach
    void setUp() {
        tree = new MorseCodeTree();
    }

    @AfterEach
    void tearDown() {
        tree = null;
        testArr = null;
    }

    @Test
    void testFetch() {
        assertEquals("e", tree.fetch("."));
        assertEquals("t", tree.fetch("-"));
        assertEquals("a", tree.fetch(".-"));
        assertEquals(null, tree.fetch(".-.-"));
        assertEquals("q", tree.fetch("--.-"));
    }
    
    @Test
    void testInsert() {
        tree.insert(".", "x");
        assertEquals("x", tree.fetch("."));
        tree.insert("-.", "y");
        assertEquals("y", tree.fetch("-."));
        tree.insert("--.", "g");
        assertEquals("g", tree.fetch("--."));
    }
    
    @Test
    void testToArrayList() {
        testArr = tree.toArrayList();
        assertEquals("h", testArr.get(0));
        assertEquals("s", testArr.get(1));
        assertEquals("o", testArr.get(testArr.size()-1));
        assertEquals(27, testArr.size());
    }
    
    @Test
    void testGetRoot() {
        assertEquals("", tree.getRoot().getData());
    }
    
    @Test
    void testSetRoot() {
        tree.setRoot(new TreeNode<String>("x"));
        assertEquals("x", tree.getRoot().getData());
    }
    
}




