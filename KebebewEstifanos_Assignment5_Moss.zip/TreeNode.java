package application;
/**
 * The TreeNode class represents a node in a binary tree. It has data of type T, 
 * and left and right children that are also TreeNode objects.
 *
 * @param <T> the data type of the TreeNode
 */
public class TreeNode<T> {

    protected T data;
    protected TreeNode<T> left, right;

    /**
     * Creates a new TreeNode with left and right child set to null and data set to the dataNode.
     *
     * @param dataNode the data to be stored in the TreeNode
     */
    public TreeNode(T dataNode) {
        this.data = dataNode;
        this.left = this.right = null;
    }

    /**
     * Used for making deep copies of a TreeNode object.
     *
     * @param node the TreeNode to make a copy of
     */
    public TreeNode(TreeNode<T> node) {
        if (node == null) {
            this.data = null;
            this.left = null;
            this.right = null;
        } else {
            this.data = node.data;
            this.left = node.left;
            this.right = node.right;
        }
    }


    /**
     * Returns the data within this TreeNode.
     *
     * @return the data within the TreeNode
     */
    public T getData() {
        return this.data;
    }
}
